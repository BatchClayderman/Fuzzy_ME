# Fuzzy_ME

Implementation of Fuzzy Identity-based Matchmaking Encryption
